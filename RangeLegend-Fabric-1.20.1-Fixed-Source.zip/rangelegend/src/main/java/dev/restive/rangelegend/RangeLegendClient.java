package dev.restive.rangelegend;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class RangeLegendClient implements ClientModInitializer {
    public static final RangeLegendConfig CONFIG = RangeLegendConfig.load();
    private static KeyBinding toggleKey;
    private static KeyBinding settingsKey;
    private static float smoothDistance = -1;

    @Override public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.rangelegend.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.category.rangelegend"));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.rangelegend.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.category.rangelegend"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) { CONFIG.enabled = !CONFIG.enabled; CONFIG.save(); if (client.player != null) client.player.sendMessage(Text.literal("§8[§bRangeLegend§8] §fHUD " + (CONFIG.enabled ? "§aenabled" : "§cdisabled")), true); }
            while (settingsKey.wasPressed()) { if (client.currentScreen == null) client.setScreen(new RangeLegendScreen()); }
        });
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> renderHud(MinecraftClient.getInstance(), drawContext));
    }

    private static void renderHud(MinecraftClient client, net.minecraft.client.gui.DrawContext ctx) {
        if (client.player == null || client.world == null || client.options.hudHidden) return;
        Entity target = null;
        if (client.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity && hit.getEntity() != client.player) target = hit.getEntity();
        float distance = -1;
        if (target != null) {
            Box box = target.getBoundingBox();
            double dx = MathHelper.clamp(client.player.getX(), box.minX, box.maxX) - client.player.getX();
            double dy = MathHelper.clamp(client.player.getEyeY(), box.minY, box.maxY) - client.player.getEyeY();
            double dz = MathHelper.clamp(client.player.getZ(), box.minZ, box.maxZ) - client.player.getZ();
            distance = (float)Math.sqrt(dx*dx + dy*dy + dz*dz);
        }
        if (distance >= 0) smoothDistance = smoothDistance < 0 ? distance : MathHelper.lerp(0.28f, smoothDistance, distance);
        else smoothDistance = -1;

        if (CONFIG.enabled && smoothDistance >= 0) {
            String name = target.getName().getString();
            String dist = String.format(java.util.Locale.ROOT, "%.1f blocks", smoothDistance);
            boolean inRange = smoothDistance <= CONFIG.range;
            int color = inRange ? CONFIG.inRangeColor : CONFIG.outRangeColor;
            int x = MathHelper.clamp(CONFIG.hudX, 0, Math.max(0, client.getWindow().getScaledWidth()-150));
            int y = MathHelper.clamp(CONFIG.hudY, 0, Math.max(0, client.getWindow().getScaledHeight()-40));
            int width = Math.max(client.textRenderer.getWidth(name), Math.max(client.textRenderer.getWidth(dist), 116)) + 12;
            ctx.fill(x, y, x + width, y + 39, 0xB0101220);
            ctx.fill(x, y, x + 2, y + 39, color);
            ctx.drawText(client.textRenderer, "§b" + name, x + 7, y + 5, 0xFFFFFFFF, false);
            ctx.drawText(client.textRenderer, dist, x + 7, y + 16, 0xFFFFFFFF, false);
            ctx.drawText(client.textRenderer, inRange ? "§aIN RANGE" : "§cTOO FAR", x + 7, y + 27, color, false);
        }
        if (CONFIG.customCrosshair && !client.options.hudHidden) drawCrosshair(client, ctx);
    }

    private static void drawCrosshair(MinecraftClient client, net.minecraft.client.gui.DrawContext ctx) {
        int cx = client.getWindow().getScaledWidth()/2 + CONFIG.crosshairOffsetX;
        int cy = client.getWindow().getScaledHeight()/2 + CONFIG.crosshairOffsetY;
        int s = CONFIG.crosshairSize, t = CONFIG.crosshairThickness, g = CONFIG.crosshairGap, c = CONFIG.crosshairColor;
        if (CONFIG.crosshairStyle == 0) {
            ctx.fill(cx-s, cy-t/2, cx-g, cy+(t+1)/2, c); ctx.fill(cx+g+1, cy-t/2, cx+s+1, cy+(t+1)/2, c);
            ctx.fill(cx-t/2, cy-s, cx+(t+1)/2, cy-g, c); ctx.fill(cx-t/2, cy+g+1, cx+(t+1)/2, cy+s+1, c);
        } else if (CONFIG.crosshairStyle == 1) {
            ctx.fill(cx-t/2, cy-t/2, cx+(t+1)/2, cy+(t+1)/2, c);
        } else {
            ctx.fill(cx-s, cy-s, cx+s+1, cy+s+1, 0x70000000);
            ctx.fill(cx-t/2, cy-s, cx+(t+1)/2, cy+s+1, c); ctx.fill(cx-s, cy-t/2, cx+s+1, cy+(t+1)/2, c);
        }
    }
}
