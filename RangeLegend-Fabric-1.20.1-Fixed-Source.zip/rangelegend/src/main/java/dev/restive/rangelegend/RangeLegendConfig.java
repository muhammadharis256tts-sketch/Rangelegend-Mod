package dev.restive.rangelegend;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;

public class RangeLegendConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("rangelegend.json");
    public boolean enabled = true;
    public float range = 3.0f;
    public int hudX = 12, hudY = 42;
    public int inRangeColor = 0xFF35E887, outRangeColor = 0xFFFF5364;
    public boolean customCrosshair = true;
    public int crosshairStyle = 0, crosshairSize = 5, crosshairThickness = 2, crosshairGap = 2;
    public int crosshairColor = 0xFFFFFFFF, crosshairOffsetX = 0, crosshairOffsetY = 0;
    public static RangeLegendConfig load() {
        try { if (Files.exists(FILE)) { RangeLegendConfig c = GSON.fromJson(Files.readString(FILE), RangeLegendConfig.class); if (c != null) return c; } } catch (Exception ignored) {}
        return new RangeLegendConfig();
    }
    public void save() { try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(this)); } catch (Exception ignored) {} }
}
