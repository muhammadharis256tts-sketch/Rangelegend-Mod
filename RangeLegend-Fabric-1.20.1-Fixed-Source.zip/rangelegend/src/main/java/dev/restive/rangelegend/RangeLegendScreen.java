package dev.restive.rangelegend;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

public class RangeLegendScreen extends Screen {
    private int dragOffsetX, dragOffsetY;
    private boolean dragging;
    public RangeLegendScreen() { super(Text.literal("RangeLegend Settings")); }
    @Override protected void init() {
        int cx = width/2, y = 38;
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD: " + (RangeLegendClient.CONFIG.enabled ? "ON" : "OFF")), b -> { RangeLegendClient.CONFIG.enabled = !RangeLegendClient.CONFIG.enabled; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("HUD: " + (RangeLegendClient.CONFIG.enabled ? "ON" : "OFF"))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal(String.format(java.util.Locale.ROOT,"Target range: %.1f blocks", RangeLegendClient.CONFIG.range)), b -> { RangeLegendClient.CONFIG.range += 0.5f; if (RangeLegendClient.CONFIG.range > 6.0f) RangeLegendClient.CONFIG.range = 1.0f; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal(String.format(java.util.Locale.ROOT,"Target range: %.1f blocks", RangeLegendClient.CONFIG.range))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("In-range color: " + colorName(RangeLegendClient.CONFIG.inRangeColor)), b -> { RangeLegendClient.CONFIG.inRangeColor = nextColor(RangeLegendClient.CONFIG.inRangeColor); RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("In-range color: " + colorName(RangeLegendClient.CONFIG.inRangeColor))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Too-far color: " + colorName(RangeLegendClient.CONFIG.outRangeColor)), b -> { RangeLegendClient.CONFIG.outRangeColor = nextColor(RangeLegendClient.CONFIG.outRangeColor); RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Too-far color: " + colorName(RangeLegendClient.CONFIG.outRangeColor))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Custom crosshair: " + (RangeLegendClient.CONFIG.customCrosshair ? "ON" : "OFF")), b -> { RangeLegendClient.CONFIG.customCrosshair = !RangeLegendClient.CONFIG.customCrosshair; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Custom crosshair: " + (RangeLegendClient.CONFIG.customCrosshair ? "ON" : "OFF"))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Crosshair style: " + styleName()), b -> { RangeLegendClient.CONFIG.crosshairStyle = (RangeLegendClient.CONFIG.crosshairStyle+1)%3; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Crosshair style: " + styleName())); }).dimensions(cx-105,y,20+190,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Crosshair color: " + colorName(RangeLegendClient.CONFIG.crosshairColor)), b -> { RangeLegendClient.CONFIG.crosshairColor = nextColor(RangeLegendClient.CONFIG.crosshairColor); RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Crosshair color: " + colorName(RangeLegendClient.CONFIG.crosshairColor))); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Size: " + RangeLegendClient.CONFIG.crosshairSize + "  |  Thickness: " + RangeLegendClient.CONFIG.crosshairThickness), b -> { RangeLegendClient.CONFIG.crosshairSize = RangeLegendClient.CONFIG.crosshairSize >= 12 ? 3 : RangeLegendClient.CONFIG.crosshairSize+1; RangeLegendClient.CONFIG.crosshairThickness = RangeLegendClient.CONFIG.crosshairThickness >= 4 ? 1 : RangeLegendClient.CONFIG.crosshairThickness+1; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Size: " + RangeLegendClient.CONFIG.crosshairSize + "  |  Thickness: " + RangeLegendClient.CONFIG.crosshairThickness)); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Gap: " + RangeLegendClient.CONFIG.crosshairGap), b -> { RangeLegendClient.CONFIG.crosshairGap = (RangeLegendClient.CONFIG.crosshairGap+1)%8; RangeLegendClient.CONFIG.save(); b.setMessage(Text.literal("Gap: " + RangeLegendClient.CONFIG.crosshairGap)); }).dimensions(cx-105,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset HUD position"), b -> { RangeLegendClient.CONFIG.hudX=12; RangeLegendClient.CONFIG.hudY=42; RangeLegendClient.CONFIG.save(); }).dimensions(cx-105,y,210,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(cx-50,height-28,100,20).build());
    }
    private String styleName() { return switch (RangeLegendClient.CONFIG.crosshairStyle) { case 1 -> "Dot"; case 2 -> "Plus"; default -> "Classic"; }; }
    private static int nextColor(int c) { int[] colors={0xFFFFFFFF,0xFF35E887,0xFFFF5364,0xFF55C8FF,0xFFCE77FF,0xFFFFD166,0xFFFF8A3D}; for(int i=0;i<colors.length;i++) if(colors[i]==c) return colors[(i+1)%colors.length]; return colors[1]; }
    private static String colorName(int c) { return switch(c) { case 0xFF35E887 -> "Green"; case 0xFFFF5364 -> "Red"; case 0xFF55C8FF -> "Blue"; case 0xFFCE77FF -> "Purple"; case 0xFFFFD166 -> "Gold"; case 0xFFFF8A3D -> "Orange"; default -> "White"; }; }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx); super.render(ctx,mouseX,mouseY,delta);
        ctx.drawCenteredTextWithShadow(textRenderer,"§bRANGELEGEND §7• §fPvP HUD",width/2,15,0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,"§7Drag the preview box to move the HUD",width/2,height-42,0xFFFFFFFF);
        int x=RangeLegendClient.CONFIG.hudX, y=RangeLegendClient.CONFIG.hudY;
        x=MathHelper.clamp(x,0,Math.max(0,width-130)); y=MathHelper.clamp(y,0,Math.max(0,height-39));
        ctx.fill(x,y,x+130,y+39,0xD0101220); ctx.fill(x,y,x+2,y+39,RangeLegendClient.CONFIG.inRangeColor);
        ctx.drawText(textRenderer,"§bTargetPlayer",x+7,y+5,0xFFFFFFFF,false); ctx.drawText(textRenderer,"2.4 blocks",x+7,y+16,0xFFFFFFFF,false); ctx.drawText(textRenderer,"§aIN RANGE",x+7,y+27,RangeLegendClient.CONFIG.inRangeColor,false);
        int cx=width/2+RangeLegendClient.CONFIG.crosshairOffsetX, cy=height/2+RangeLegendClient.CONFIG.crosshairOffsetY;
        if(RangeLegendClient.CONFIG.customCrosshair) { int s=RangeLegendClient.CONFIG.crosshairSize,t=RangeLegendClient.CONFIG.crosshairThickness,g=RangeLegendClient.CONFIG.crosshairGap,c=RangeLegendClient.CONFIG.crosshairColor; if(RangeLegendClient.CONFIG.crosshairStyle==1) ctx.fill(cx-t/2,cy-t/2,cx+(t+1)/2,cy+(t+1)/2,c); else if(RangeLegendClient.CONFIG.crosshairStyle==2) {ctx.fill(cx-t/2,cy-s,cx+(t+1)/2,cy+s+1,c);ctx.fill(cx-s,cy-t/2,cx+s+1,cy+(t+1)/2,c);} else {ctx.fill(cx-s,cy-t/2,cx-g,cy+(t+1)/2,c);ctx.fill(cx+g+1,cy-t/2,cx+s+1,cy+(t+1)/2,c);ctx.fill(cx-t/2,cy-s,cx+(t+1)/2,cy-g,c);ctx.fill(cx-t/2,cy+g+1,cx+(t+1)/2,cy+s+1,c);} }
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) { int x=RangeLegendClient.CONFIG.hudX,y=RangeLegendClient.CONFIG.hudY; if(button==0 && mouseX>=x && mouseX<=x+140 && mouseY>=y && mouseY<=y+45) {dragging=true;dragOffsetX=(int)mouseX-x;dragOffsetY=(int)mouseY-y;return true;} return super.mouseClicked(mouseX,mouseY,button); }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double deltaX,double deltaY) { if(dragging) {RangeLegendClient.CONFIG.hudX=MathHelper.clamp((int)mouseX-dragOffsetX,0,Math.max(0,width-140));RangeLegendClient.CONFIG.hudY=MathHelper.clamp((int)mouseY-dragOffsetY,0,Math.max(0,height-45));return true;} return super.mouseDragged(mouseX,mouseY,button,deltaX,deltaY); }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button) { if(dragging){dragging=false;RangeLegendClient.CONFIG.save();return true;} return super.mouseReleased(mouseX,mouseY,button); }
    @Override public void close() { RangeLegendClient.CONFIG.save(); if(client!=null) client.setScreen(null); }
}
