# RangeLegend — Fabric 1.20.1

A lightweight client-side PvP target-distance HUD and configurable crosshair. Intended for Minecraft Java 1.20.1 with Fabric Loader and Fabric API.

## Features in this source version
- Target player name and estimated distance to the target's bounding box
- Configurable distance threshold with in-range / too-far colors
- Draggable HUD preview in the settings screen
- H toggles the HUD; J opens settings (change these in Minecraft Controls)
- Crosshair presets (classic, dot, plus), color, size, thickness and gap
- JSON config saved to `.minecraft/config/rangelegend.json`

This is a client-side range estimate, not a guarantee that an attack will register. Server-side reach, latency, and combat rules still apply. It does not extend reach or automate attacks.

## Build the JAR
Requires an internet connection on the build machine for Gradle/Minecraft/Fabric dependencies and Java 17.

### On a computer with Gradle 8.6 installed
Run from this project directory:
```bash
gradle --no-daemon build
```
The compiled mod will be in `build/libs/`, normally `rangelegend-1.0.0.jar`.

### Build through GitHub Actions (no Gradle setup needed locally)
1. Create a GitHub repository and upload the contents of this folder to it.
2. Open the repository's **Actions** tab and select **Build RangeLegend**.
3. Click **Run workflow**. Wait for the workflow to finish successfully.
4. Open that completed run and download the **RangeLegend-Fabric-1.20.1** artifact. It contains the built JAR.

## Install
1. Install Fabric Loader for Minecraft 1.20.1 and Fabric API for 1.20.1.
2. Put `rangelegend-1.0.0.jar` into `.minecraft/mods`.
3. Launch the Fabric 1.20.1 profile. Press **H** to toggle the HUD and **J** to open settings.

## Limitations
This is an initial source build, not yet verified in a live game. The crosshair supports presets and adjustable settings; freehand pixel drawing and arbitrary color entry are not implemented in this version.
